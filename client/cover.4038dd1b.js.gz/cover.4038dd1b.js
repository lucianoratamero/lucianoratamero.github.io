var a="/client/71a9ff9732f6eb60.png";export{a as c};
